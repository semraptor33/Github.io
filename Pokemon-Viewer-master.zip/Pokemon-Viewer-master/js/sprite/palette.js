class Palette{
  constructor(){

  }

}
